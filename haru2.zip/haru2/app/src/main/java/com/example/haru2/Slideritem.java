package com.example.haru2;

public class Slideritem {
    private int image;
    Slideritem(int image){
        this.image=image;
    }

    public int getImage() {
        return image;
    }
}
